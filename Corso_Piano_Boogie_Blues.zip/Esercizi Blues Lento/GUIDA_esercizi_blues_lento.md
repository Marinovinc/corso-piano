# Imparare il blues lento a due mani — guida agli esercizi

`[sessione 3c88c123, 02/10/2026]` — progressione per principiante adulto, Yamaha PSR-S950,
con Synthesia. Compagna della serie boogie-woogie.

Il blues lento e' **piu' facile del boogie** per iniziare: ci sono meno note e piu' spazio, e
tutto gira attorno a una cosa sola, la **terzina** (il "respiro" ternario: *un-due-tre, un-due-tre*).
Se interiorizzi quella, il resto viene.

**Collegamento tastiera e Synthesia:** identico alla serie boogie (cavo USB "TO HOST", seleziona la
PSR-S950 come ingresso, usa la Modalita' di attesa e studia una mano alla volta). Vedi la guida
nella cartella `Esercizi Boogie Woogie` per i dettagli.

---

## La progressione (8 esercizi, in DO)

| # | File | Cosa impari | Mani |
|---|---|---|---|
| 1 | `..._01_La_terzina` | **la terzina**: contare e sentire il feel ternario del blues lento | entrambe (semplice) |
| 2 | `..._02_Scala_blues_terzine` | la scala blues suonata a terzine con la destra | destra + bordone |
| 3 | `..._03_Shuffle_sinistra` | lo **shuffle a due note** (fondamentale + quinta/sesta): la sinistra del blues | solo sinistra |
| 4 | `..._04_Shuffle_12battute` | lo shuffle sul **giro di 12 battute** (DO-FA-SOL) | solo sinistra |
| 5 | `..._05_Lick_destra` | un **lick** (frase) blues con la destra, ripetuto | destra + nota tenuta |
| 6 | `..._06_Lick_e_shuffle` | mettere insieme lick destro e shuffle sinistro | due mani |
| 7 | `..._07_Turnaround` | il **turnaround**: il giro di chiusura, vocabolario base del blues | due mani |
| 8 | `..._08_Blues_lento_completo` | un **blues lento completo** di 12 battute | due mani |

Tempi 60-66 BPM: lenti apposta. Ogni file ha il suo **MP3**: ascolta prima, poi suona.

---

## Le due cose che contano nel blues lento

- **La terzina.** Tutto e' diviso in tre. Conta ad alta voce *"uno-e-a, due-e-a"* mentre suoni
  l'esercizio 1 finche' non ti viene naturale. E' la chiave di tutto il genere.
- **Lo spazio.** Nel blues lento le pause valgono quanto le note. Non riempire: lascia respirare.
  Un lick semplice suonato al momento giusto vale piu' di tante note.

Per il resto valgono le stesse regole della serie boogie: **sinistra prima, da sola, lenta**;
**poco e spesso**; **lento batte veloce**. E non e' una gara: goditela.

---

## Onesta' sui file

Generati nota per nota (non trascritti): puliti, precisi, mani separate. Sono esercizi didattici
essenziali che ti danno il vocabolario del blues (terzina, shuffle, giro di 12, lick, turnaround).
Non sostituiscono un insegnante — diteggiatura, tocco e "swing" veri si affinano con un maestro e
ascoltando i grandi — ma per cominciare da solo sono una base solida. Quando questi ti vengono bene,
nella cartella `Blues` hai 22 brani veri col piano gia' separato (BB King, Ray Charles, Little
Walter, Jelly Roll Morton...): il passo successivo.
