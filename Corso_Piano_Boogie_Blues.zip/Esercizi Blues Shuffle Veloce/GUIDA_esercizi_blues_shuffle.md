# Blues shuffle veloce — guida agli esercizi

`[sessione 3c88c123, 02/10/2026]` — stile jump blues / Chuck Berry. Per Yamaha PSR-S950 + Synthesia.
Terza serie, dopo boogie e blues lento.

Lo shuffle veloce e' il blues "che tira": la stessa mano sinistra del blues lento, ma piu' svelta e
con piu' spinta, e una destra a **doppie note** (bicordi) che scivolano. E' il suono di Chuck Berry e
del rock and roll delle origini. **Attenzione:** e' la serie piu' impegnativa — non avere fretta di
andare veloce. Qui si parte a tempo medio e si accelera un passo alla volta.

**Collegamento tastiera e Synthesia:** come sempre (cavo USB "TO HOST", seleziona la PSR-S950,
Modalita' di attesa, una mano alla volta). Dettagli nella guida della cartella `Esercizi Boogie
Woogie`.

---

## La progressione (8 esercizi, in DO, tempi crescenti)

| # | File | BPM | Cosa impari | Mani |
|---|---|---|---|---|
| 1 | `..._01_Tempo_medio` | 96 | lo shuffle che spinge, ancora comodo | solo sinistra |
| 2 | `..._02_Piu_veloce` | 120 | lo stesso, piu' svelto: resistenza della mano | solo sinistra |
| 3 | `..._03_Bicordi_destra` | 104 | i **bicordi** della destra (G+B / A+C): il suono Chuck Berry | due mani |
| 4 | `..._04_Riff_veloce` | 112 | un riff svelto ripetuto sopra lo shuffle | due mani |
| 5 | `..._05_12battute_veloce` | 120 | lo shuffle sul **giro di 12 battute** | solo sinistra |
| 6 | `..._06_12battute_due_mani` | 120 | il giro completo a due mani | due mani |
| 7 | `..._07_Accenti_e_stop` | 120 | la **dinamica**: tre battute che corrono, una che si ferma di colpo | due mani |
| 8 | `..._08_Shuffle_completo` | 132 | lo **shuffle veloce completo** di 12 battute | due mani |

Ogni file ha il suo **MP3**: ascoltalo prima, cosi' senti la spinta giusta.

---

## I due segreti dello shuffle veloce

- **La velocita' si costruisce, non si forza.** Resta su un esercizio finche' e' pulito e rilassato
  al suo tempo, poi passa al successivo. Se la mano si irrigidisce, sei andato troppo veloce: torna
  indietro. In Synthesia puoi rallentare qualunque esercizio quanto vuoi.
- **La spinta sta nella mano sinistra.** E' lei che "tira" il brano. Tienila regolare come un
  motore: e' la regolarita', non la forza, a dare l'energia.

Valgono le solite regole: sinistra prima da sola; poco e spesso; rilassa spalle e polsi. Se senti
tensione o fatica, fermati — non c'e' nessuna gara.

---

## Onesta' sui file

Generati nota per nota: puliti, mani separate, tempi crescenti. Sono esercizi didattici che ti danno
il vocabolario dello shuffle veloce (shuffle di spinta, bicordi, riff svelti, accenti e stop). Non
sostituiscono un insegnante — la velocita' vera, il tocco e lo "swing" si affinano col tempo e
ascoltando i grandi — ma come palestra progressiva sono una base solida. Quando questi ti vengono
bene, nella cartella `Blues` hai brani veri dove lo shuffle e' protagonista.
