# Corso di pianoforte — Boogie-Woogie & Blues per principianti

Un corso gratuito per imparare il boogie-woogie e il blues a due mani, con file MIDI e un'app che
mostra le note che scendono (stile Synthesia). Pensato per chi parte da zero, anche in eta' adulta.

## Come iniziare

1. Apri **`PERCORSO_PIANO_boogie_blues.html`** (doppio clic): e' la guida completa, con il percorso
   di studio, i consigli e l'elenco delle app.
2. Scarica un'app per suonare i MIDI (vedi la guida): **Synthesia** (consigliata) oppure
   **Neothesia** (gratis), oppure aprili nel browser con **PianoFall** / **Midiano**.
3. Parti dall'esercizio 1 della cartella `Esercizi Boogie Woogie`. Un tasto alla volta.

## Cosa contiene

- **Esercizi Boogie Woogie** — 24 esercizi progressivi
- **Esercizi Blues Lento** — 8 esercizi
- **Esercizi Blues Shuffle Veloce** — 8 esercizi

Ogni cartella ha la sua guida; ogni esercizio ha un file MIDI (`.mid`) e un MP3 di ascolto.
Tutti gli esercizi hanno la mano destra e la sinistra su tracce separate, e sono stati verificati
perche' le due mani siano armonicamente coordinate.

## Licenza e uso

- Gli **esercizi** (MIDI e MP3) sono materiale **originale**, creati apposta per questo corso:
  puoi usarli, copiarli e condividerli liberamente per studiare.
- Gli MP3 di ascolto sono stati generati con il soundfont **FluidR3 GM** (licenza libera).

## Nota: i brani veri non sono inclusi

Questo corso contiene **esercizi**, non brani famosi. Per esercitarti su boogie e blues veri
(Pine Top Smith, BB King, ecc.) cerca i file MIDI sulle raccolte libere online (per esempio
MidiWorld, BitMidi): molti di quei brani sono pero' sotto copyright e non possono essere
ridistribuiti, quindi vanno scaricati da ciascun utente per uso personale.

Buono studio, e un tasto alla volta.
