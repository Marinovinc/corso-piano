# Imparare il boogie-woogie a due mani — guida agli esercizi

`[sessione 3c88c123, 02/10/2026]` — Esercizi generati su misura per principiante adulto,
tastiera **Yamaha PSR-S950** (61 tasti), con **Synthesia**.

Benvenuto. Il boogie-woogie e' il genere giusto per iniziare da adulti: la mano sinistra fa un
motivo che si **ripete sempre uguale**, quindi una volta "entrato nelle dita" sei gia' a meta'
dell'opera. Niente fretta: a questa eta' si impara benissimo, basta andare piano e ripetere.

**Regola d'oro: prima la mano sinistra, da sola, lentissima. E' il motore di tutto.**

---

## Come preparare Synthesia con la PSR-S950

1. Collega la tastiera al PC con il cavo **USB "TO HOST"** (quello che va al computer).
2. Apri Synthesia -> **Impostazioni -> Dispositivi musicali**: deve comparire la Yamaha come
   ingresso. Selezionala.
3. Apri un esercizio (file `.mid`). Synthesia mostra due righe di note che scendono: una per la
   **mano destra** (Right Hand) e una per la **sinistra** (Left Hand).
4. Attiva la **Modalita' di attesa** ("Melody Practice" / "Wait"): le note si fermano finche' non
   premi il tasto giusto. E' la funzione che fa la differenza per chi inizia — non resti mai indietro.
5. Per esercitare **una mano sola**, in Synthesia imposta l'altra mano su "la suona Synthesia".

Suggerimento: tieni accanto anche il file **MP3** di ogni esercizio (nella stessa cartella). Prima
**ascolta** come suona, poi provalo. L'orecchio aiuta le dita.

---

## La progressione (8 esercizi, in DO / C)

Fai ogni esercizio finche' non ti viene **comodo e rilassato**, poi passa al successivo. Puoi stare
giorni sullo stesso: e' normale e giusto.

| # | File | Cosa impari | Mani |
|---|---|---|---|
| 1 | `..._01_Riscaldamento_5dita` | muovere le dita, le due mani insieme (stesse note) | entrambe |
| 2 | `..._02_Scala_blues_destra` | il **suono blues** con la destra; la sinistra tiene una nota | destra + bordone |
| 3 | `..._03_Basso_ottave_sinistra` | il basso "oom-pah" a ottave: il battito del boogie | **solo sinistra** |
| 4 | `..._04_Basso_boogie_classico` | il **basso boogie classico** (8 note per battuta): l'icona del genere | **solo sinistra** |
| 5 | `..._05_Basso_12battute` | lo stesso basso sul **giro di 12 battute** (DO-FA-SOL): la forma del blues | **solo sinistra** |
| 6 | `..._06_Accordi_backbeat` | accordi con la destra sui tempi 2 e 4, sopra il basso | due mani |
| 7 | `..._07_Riff_destro_e_basso` | un **riff** con la destra mentre la sinistra fa il basso boogie | due mani |
| 8 | `..._08_Mini_boogie_completo` | un piccolo **boogie completo** di 12 battute: il traguardo | due mani |

### Approfondimenti (dopo i primi 8)

| # | File | Cosa impari | Mani |
|---|---|---|---|
| 9 | `..._09_Basso_in_FA` | lo stesso basso boogie partendo da **FA** (l'accordo IV del giro) | solo sinistra |
| 10 | `..._10_Basso_in_SOL` | lo stesso basso partendo da **SOL** (l'accordo V) | solo sinistra |
| 11 | `..._11_Cambi_posizione` | **spostare la mano** fra DO-FA-SOL: il punto piu' difficile del giro, lento | solo sinistra |
| 12 | `..._12_Variazioni_riff_destro` | **quattro riff** diversi per la destra sopra il basso in DO | due mani |

Gli esercizi 9-11 servono a rendere automatico il basso nelle tre posizioni del giro di 12 battute
(DO, FA, SOL): quando i cambi dell'esercizio 11 non ti fanno piu' pensare, il giro completo
(esercizio 5) e il mini-boogie (esercizio 8) diventano molto piu' facili.

### Tecniche della mano destra e varianti (dopo i primi 12)

| # | File | Cosa impari | Mani |
|---|---|---|---|
| 13 | `..._13_Turnaround` | il **turnaround**: la chiusura che "chiama" il ritorno (accordo di SOL7) | due mani |
| 14 | `..._14_Acciaccature` | le **note schiacciate** (mezzo tono sotto, poi la nota): il suono tipico del blues | destra + basso |
| 15 | `..._15_Tremolo` | il **tremolo**: due note alternate in fretta, l'effetto "scintillante" del boogie | destra + basso |
| 16 | `..._16_Terze_e_seste` | la destra a **due note insieme** (seste): rende il suono pieno | destra + basso |
| 17 | `..._17_Walking_bass` | il **walking bass**: un basso "camminato" a note di 1/4, alternativa allo shuffle | solo sinistra |
| 18 | `..._18_Boogie_in_SOL` | un **boogie completo in SOL**: uscire dalla tonalita' di DO | due mani |

Gli esercizi 13-16 sono gli ornamenti veri del boogie-woogie: quando li aggiungi al mini-boogie
(esercizio 8) il tuo modo di suonare diventa subito piu' "autentico". Il 17 ti da' una seconda mano
sinistra, il 18 ti fa provare un'altra tonalita' — il segno che stai davvero imparando il genere,
non un solo brano.

### Verso il brano vero (esercizi avanzati)

| # | File | Cosa impari | Mani |
|---|---|---|---|
| 19 | `..._19_Boogie_in_FA` | un **boogie completo in FA**: la terza tonalita' comoda | due mani |
| 20 | `..._20_Break_stoptime` | il **break (stop-time)**: la sinistra si ferma, la destra riempie il silenzio | due mani |
| 21 | `..._21_Glissando` | il **glissando**: la corsa veloce della destra verso l'acuto | destra + basso |
| 22 | `..._22_Basso_tempo_medio` | lo stesso basso a **96 BPM**: cominciare a prendere velocita' | solo sinistra |
| 23 | `..._23_Domanda_risposta` | **domanda e risposta**: una frase media, poi una acuta che "risponde" | due mani |
| 24 | `..._24_Pezzo_finale` | il **pezzo finale**: 24 battute con riff, tremolo e turnaround | due mani |

Il numero 24 e' il traguardo della serie: due giri di 12 battute che mettono insieme quasi tutto
quello che hai imparato. Quando lo suoni dall'inizio alla fine, anche lento, **sai suonare il
boogie-woogie**. Da li', i brani veri nella cartella `Boogie Woogie` sono il passo naturale.

I tempi sono lenti apposta (66-76 BPM). Quando un esercizio ti viene bene, in Synthesia puoi
**rallentarlo ancora** per curare la precisione, o accelerarlo pian piano.

---

## Consigli pratici (specie per chi inizia da adulto)

- **Mani separate, sempre, all'inizio.** Prima la sinistra da sola finche' va "in automatico",
  poi aggiungi la destra. Mettere insieme le due mani e' la parte difficile: non saltarla.
- **Lento batte veloce.** Suonare lento e pulito vale piu' che suonare in fretta e sbagliato. La
  velocita' arriva da sola.
- **Poco e spesso.** 15-20 minuti al giorno rendono piu' di due ore una volta a settimana.
- **Il basso non si ferma mai.** Nel boogie la sinistra e' un motore che gira sempre uguale: e'
  proprio la ripetizione che la rende facile col tempo.
- **Rilassa spalle e polsi.** Se senti tensione, fermati un minuto. Niente dolore.

---

## Cosa sono questi file, con onesta'

Li ho **generati io nota per nota** (non trascritti da registrazioni), quindi sono puliti, precisi e
con le mani gia' separate. Sono esercizi *didattici*, essenziali: ti danno i mattoni veri del
boogie (basso a ottave, basso 8-to-the-bar, giro di 12 battute, riff, accordi). **Non** sostituiscono
un insegnante o un metodo: un maestro ti cura la **diteggiatura** e la **postura**, che un file MIDI
non puo' insegnare. Ma per cominciare da solo, con Synthesia che ti aspetta, sono un ottimo punto di
partenza — e sono tutti in DO, la tonalita' piu' facile.

Quando questi ti vengono bene, nella cartella `Boogie Woogie` hai i brani veri (Pine Top Smith,
Rob Rio, ecc.) gia' a mani separate: il passo successivo.

Buon divertimento, e un tasto alla volta.
